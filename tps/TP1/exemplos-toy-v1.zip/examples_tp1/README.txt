Caros, estes são alguns casos de teste toy para vocês testarem o resultado de vocês.
Caso alguns não consigam obter os mesmos resultados, em alguns testes nos comunique pelo forum de discussão. Caso o erro esteja nos nossos casos de teste, pedimos desculpas por qualquer inconveniente causado.

Atenciosamente,
 Monitores 2018-2.
